package com.example.lazismu.ketek;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {
    private EditText emailtext;
    private EditText passtext;

    private ProgressBar progress;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailtext = findViewById(R.id.editText2);
        passtext = findViewById(R.id.editText);
        Button loginbtn = findViewById(R.id.buttonLogin);
        TextView registers = findViewById(R.id.textViews);

        progress = findViewById(R.id.progressBar);
        mAuth = FirebaseAuth.getInstance();

        registers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent regis = new Intent(Login.this, daftar.class);
                startActivity(regis);

            }
        });

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String emaillogin = emailtext.getText().toString();
                String passlogin = passtext.getText().toString();

                if(!TextUtils.isEmpty(emaillogin) && !TextUtils.isEmpty(passlogin)){

                    progress.setVisibility(View.VISIBLE);
                    mAuth.signInWithEmailAndPassword(emaillogin, passlogin).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful()){

                                sendToMain();

                            } else {

                                String errors = task.getException().getMessage();
                                Toast.makeText(Login.this, "Error " + errors, Toast.LENGTH_LONG).show();

                            }

                            progress.setVisibility(View.INVISIBLE);

                        }
                    });

                }

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currents = mAuth.getCurrentUser();
        if(currents != null) {

            sendToMain();

        }
    }

    private void sendToMain(){

        Intent main = new Intent(Login.this, MainMenu.class);
        startActivity(main);
        finish();
    }

}

