package com.example.lazismu.ketek;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Umkm extends AppCompatActivity {

    Button upload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_umkm);

        upload = findViewById(R.id.upload);

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Dialog unggah = new Dialog(Umkm.this, R.style.NewDialog);
                unggah.setContentView(R.layout.upload);
                unggah.setCancelable(true);
                unggah.setCanceledOnTouchOutside(true);

                unggah.show();
            }
        });
    }

}