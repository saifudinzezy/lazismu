package com.example.lazismu.ketek;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;

import java.util.HashMap;

public class MainMenu extends AppCompatActivity implements BaseSliderView.OnSliderClickListener,
        ViewPagerEx.OnPageChangeListener, View.OnClickListener {

    SliderLayout sliderLayout;

    HashMap<String, String> HashMapForURL;

    HashMap<String, Integer> HashMapForLocalRes;

    private ImageView btnZakat, btnAmbulance, btnBedahRumah, btnBeasiswa, btnUmkm, btnLokasi, btnInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        konek();

        sliderLayout = (SliderLayout) findViewById(R.id.slider);

        //Call this method if you want to add images from URL .
        AddImagesUrlOnline();

        //Call this method to add images from local drawable folder .
        //AddImageUrlFormLocalRes();

        //Call this method to stop automatic sliding.
        //sliderLayout.stopAutoCycle();

        for (String name : HashMapForURL.keySet()) {

            TextSliderView textSliderView = new TextSliderView(MainMenu.this);

            textSliderView
                    .description(name)
                    .image(HashMapForURL.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(this);

            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra", name);

            sliderLayout.addSlider(textSliderView);
        }
        sliderLayout.setPresetTransformer(SliderLayout.Transformer.DepthPage);

        sliderLayout.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);

        sliderLayout.setCustomAnimation(new DescriptionAnimation());

        sliderLayout.setDuration(3000);

        sliderLayout.addOnPageChangeListener(MainMenu.this);
    }

    @Override
    protected void onStop() {

        sliderLayout.stopAutoCycle();

        super.onStop();
    }

    @Override
    public void onSliderClick(BaseSliderView slider) {
        // logika click disini
        Toast.makeText(this, slider.getBundle().get("extra") + "", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
    }

    @Override
    public void onPageSelected(int position) {

        Log.d("Slider Demo", "Page Changed: " + position);

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    public void AddImagesUrlOnline() {

        HashMapForURL = new HashMap<String, String>();

        HashMapForURL.put("CupCake", "http://androidblog.esy.es/images/cupcake-1.png");
        HashMapForURL.put("Donut", "http://androidblog.esy.es/images/donut-2.png");
        HashMapForURL.put("Eclair", "http://androidblog.esy.es/images/eclair-3.png");
        HashMapForURL.put("Froyo", "http://androidblog.esy.es/images/froyo-4.png");
        HashMapForURL.put("GingerBread", "http://androidblog.esy.es/images/gingerbread-5.png");
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.imageView5:
                //Toast.makeText(this, "klik", Toast.LENGTH_SHORT).show();
                Buka.buka(MainMenu.this, Zakat.class);
                break;
            case R.id.imageView4:
                Buka.buka(MainMenu.this, Ambulan.class);
                break;
            case R.id.imageView6:
                Buka.buka(MainMenu.this, Bedahrumah.class);
                break;
            case R.id.imageView7:
                Buka.buka(MainMenu.this, Beasiswa.class);
                break;
            case R.id.imageView8:
                Buka.buka(MainMenu.this, Umkm.class);
                break;
            case R.id.imageView9:
                Buka.buka(MainMenu.this, Login.class);
                break;
            case R.id.imageView2:
                //Buka.buka(MainMenu.this, Login.class);
                Toast.makeText(this, "ini Info", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void konek() {
        btnZakat = findViewById(R.id.imageView5);
        btnAmbulance = findViewById(R.id.imageView4);
        btnBedahRumah = findViewById(R.id.imageView6);
        btnBeasiswa = findViewById(R.id.imageView7);
        btnUmkm = findViewById(R.id.imageView8);
        btnLokasi = findViewById(R.id.imageView9);
        btnInfo = findViewById(R.id.imageView2);

        btnZakat.setOnClickListener(this);
        btnAmbulance.setOnClickListener(this);
        btnBedahRumah.setOnClickListener(this);
        btnBeasiswa.setOnClickListener(this);
        btnUmkm.setOnClickListener(this);
        btnLokasi.setOnClickListener(this);
        btnInfo.setOnClickListener(this);
    }
}
